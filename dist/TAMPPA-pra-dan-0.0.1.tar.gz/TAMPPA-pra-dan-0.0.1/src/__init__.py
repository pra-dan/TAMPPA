from .tamppa import tamppa
